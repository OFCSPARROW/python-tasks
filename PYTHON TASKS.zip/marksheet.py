tamil= 60
english= 45
maths= 35
science= 77
social = 80

if tamil>35:
    print("tamil pass")
else:
    print("tamil fail")
if english>35:
    print("english pass")
else:
    print("english fail")
if maths>35:
    print("maths pass")
else:
    print("maths fail")
if science>35:
    print("science pass")
else:
    print("science fail")
if social>35:
    print("social pass")
else:
    print("social fail")
