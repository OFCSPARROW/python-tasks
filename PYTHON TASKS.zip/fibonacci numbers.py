a=0
b=1
while a<20:
    c=a
    a=b
    b=c+b
    print(a)



