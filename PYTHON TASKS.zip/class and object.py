class stack():
    def pe_stack(self):
        self.a1=20
        self.b1=25
        self.c1=30

    def as_stack(self):
        self.d1=35
        self.e1=25
        self.f1=15

    def ls_stack(self):
        self.g1=20
        self.h1=25
        self.i1=25

class shirts(stack):
    def peter_england(self):
        print("---1.peter england---")
        self.a="1.cotton = 300$"
        self.b="2.jeans  = 600$"
        self.c="3.formel = 450$"
        print(self.a,'\n',self.b,'\n',self.c)

    def allen_solly(self):
        print("---2.allen solly---")
        self.d = "1.cotton = 400$"
        self.e = "2.jeans  = 700$"
        self.f = "3.formel = 500$"
        print(self.d,'\n',self.e,'\n',self.f)

    def levis(self):
        print("---3.levis---")
        self.g = "1.cotton = 4504"
        self.h = "2.jeans  = 650$"
        self.i = "3.formel = 550$"
        print(self.g,'\n',self.h,'\n',self.i)


class bill(shirts):
    def billing(self):
        self.br=input("Enter Your Shirt Brand Number")
        self.mt=input("Enter your Shirt Material Number")
        self.qt=input("Enter Your Quantity Of Shirt ")
        if self.br=="1":
            if self.mt == "1" and self.a1 !=0:
                add1 = int(self.qt) * 300
                self.a1 = self.a1 - 1
                print(self.qt,"shirt","total=",add1)
            elif self.mt == "2" and self.b1 !=0:
                add2 = int(self.qt) * 600
                self.b1 = self.b1 - 1
                print(self.qt, "shirt", "total=", add2)
            elif self.mt == "3" and self.c1 !=0:
                add3 = int(self.qt) * 450
                self.c1 = self.c1 - 1
                print(self.qt, "shirt", "total=", add3)
        elif self.br=="2":
            if self.mt == "1" and self.d1 !=0:
                add4 = int(self.qt) * 400
                self.d1 = self.d1 - 1
                print(self.qt,"shirt","total=",add4)
            elif self.mt == "2" and self.e1 !=0:
                add5 = int(self.qt) * 700
                self.e1 = self.e1 - 1
                print(self.qt, "shirt", "total=", add5)
            elif self.mt == "3" and self.f1 !=0:
                add6 = int(self.qt) * 500
                self.f1 = self.f1 - 1
                print(self.qt, "shirt", "total=", add6)
        elif self.br=="3":
            if self.mt == "1" and self.g1 !=0:
                add7 = int(self.qt) * 450
                self.g1 = self.g1 - 1
                print(self.qt,"shirt","total=",add7)
            elif self.mt == "2" and self.h1 !=0:
                add8 = int(self.qt) * 650
                self.h1 = self.h1 - 1
                print(self.qt, "shirt", "total=", add8)
            elif self.mt == "3" and self.i1 !=0:
                add9 = int(self.qt) * 550
                self.i1 = self.i1 - 1
                print(self.qt, "shirt", "total=", add9)




men=bill()
men.pe_stack()
men.as_stack()
men.ls_stack()
men.peter_england()
men.allen_solly()
men.levis()
men.billing()
