# odd number
a=0
while a<10:
    a=a+1
    print(a*2-1)
# even number
b=1
while b<10:
    b=b+1
    print(b*2-2)