def ice():
    print("hello welcome to sparrow ice cream shop")
    a="1.cup ice cream"
    b="2.cone ice cream"
    c="3.stick ice cream"
    print(a,"\n",b,"\n",c)

    name=int(input("Enter Your Number->"))

    if name==1:
        print(a)
        ice1()
    elif name==2:
        print(b)
        ice1()
    elif name==3:
        print(c)
        ice1()
    elif name>3:
        print("Pls Enter The Available Number")
        ice()

def ice1():
    print("=>flavors<=")
    d="1.vennila=40$"
    e="2.strawberry=60$"
    f="3.chocolate=80$"
    print(d,"\n",e,"\n",f)
    flavor=int(input("Enter Your Number->"))
    if flavor==1:
        q1=int(input("Enter Your Quantity->"))
        w1=q1*40
        print("total amount =",w1)
    elif flavor==2:
        q2=int(input("Enter Your Quantity->"))
        w2=q2*60
        print("Total Amount =",w2)
    elif flavor==3:
        q3=int(input("Enter Your Quantity->"))
        w3=q3*80
        print("total amount =",w3)
    elif flavor>3:
        print("pls enter the available number")
        ice1()

    con=input("did u want continue?type yes or no->")
    if con=="yes":
        ice()
    else:
        print("thank you!!! come next time!!")

ice()


